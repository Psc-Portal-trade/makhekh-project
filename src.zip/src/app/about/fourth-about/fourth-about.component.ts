import { Component } from '@angular/core';
import { TranslocoPipe } from '@ngneat/transloco';

@Component({
  selector: 'app-fourth-about',
  imports: [TranslocoPipe],
  templateUrl: './fourth-about.component.html',
  styleUrl: './fourth-about.component.css'
})
export class FourthAboutComponent {

}
