import { Component } from '@angular/core';
import { TranslocoPipe } from '@ngneat/transloco';

@Component({
  selector: 'app-third-about',
  imports: [TranslocoPipe],
  templateUrl: './third-about.component.html',
  styleUrl: './third-about.component.css'
})
export class ThirdAboutComponent {

}
