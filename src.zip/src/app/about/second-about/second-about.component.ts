import { Component } from '@angular/core';
import { TranslocoPipe } from '@ngneat/transloco';

@Component({
  selector: 'app-second-about',
  imports: [TranslocoPipe],
  templateUrl: './second-about.component.html',
  styleUrl: './second-about.component.css'
})
export class SecondAboutComponent {

}
