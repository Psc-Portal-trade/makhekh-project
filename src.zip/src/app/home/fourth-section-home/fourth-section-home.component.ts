import { Component } from '@angular/core';
import { TranslocoPipe } from '@ngneat/transloco';

@Component({
  selector: 'app-fourth-section-home',
  imports: [TranslocoPipe],
  templateUrl: './fourth-section-home.component.html',
  styleUrl: './fourth-section-home.component.css'
})
export class FourthSectionHomeComponent {

}
