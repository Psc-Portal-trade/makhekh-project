import { Component } from '@angular/core';
import { TranslocoPipe } from '@ngneat/transloco';

@Component({
  selector: 'app-third-section-home',
  imports: [TranslocoPipe],
  templateUrl: './third-section-home.component.html',
  styleUrl: './third-section-home.component.css'
})
export class ThirdSectionHomeComponent {

}
